#include <iostream>

class Vigenere_Cipher{

    public:
        Vigenere_Cipher();
        ~Vigenere_Cipher();
        void Vigenere_encrypt(std::string, std::string, std::string);
        void Vigenere_decrypt(std::string, std::string, std::string);

    private:

};